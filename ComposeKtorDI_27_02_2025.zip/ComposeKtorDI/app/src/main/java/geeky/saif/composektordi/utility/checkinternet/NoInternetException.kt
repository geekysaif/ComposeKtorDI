package geeky.saif.composektordi.utility.checkinternet

class NoInternetException(message: String) : Exception(message)
