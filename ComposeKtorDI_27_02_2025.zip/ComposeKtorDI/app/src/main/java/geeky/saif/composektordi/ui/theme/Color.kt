package geeky.saif.composektordi.ui.theme

import androidx.compose.ui.graphics.Color

val primaryColor = Color(0xFF4CAF50)
val primaryColorDark = Color(0xFF117A14)
val white = Color(0xFFF0F3F0)
val black = Color(0xFF090909)
val Pink80 = Color(0xFFEFB8C8)

